class Palette:
    RESET = "\033[0m"
    BOLD = "\033[1m"

    OCEAN = [
        (23, 16, 77),
        (37, 33, 140),
        (35, 65, 235),
        (23, 107, 239),
        (0, 205, 245),
    ]

    EMERALD = [
        (6, 61, 42),
        (8, 116, 74),
        (0, 168, 107),
        (0, 220, 125),
        (112, 255, 181),
    ]

    CRIMSON = [
        (65, 10, 25),
        (128, 17, 38),
        (197, 29, 53),
        (255, 55, 65),
        (255, 112, 40),
    ]

    # Smooth continuous rainbow
    RAINBOW = [
        (255, 45, 65),    # Red
        (255, 125, 35),   # Orange
        (255, 220, 35),   # Yellow
        (130, 220, 35),   # Lime
        (0, 200, 85),     # Green
        (0, 210, 165),    # Turquoise
        (0, 195, 255),    # Cyan
        (35, 95, 255),    # Blue
        (105, 55, 245),   # Indigo
        (175, 55, 235),   # Purple
        (235, 45, 180),   # Magenta
        (255, 75, 145),   # Pink
    ]

    WHITE = (245, 248, 255)
    RED = (255, 55, 65)
    GREEN = (0, 220, 125)
    ORANGE = (255, 112, 40)
    BLUE = (35, 65, 235)
    CYAN = (0, 205, 245)

    # Shared counter: prevents restarting when another Palette is created
    _rainbow_line_position = 0

    def __init__(self):
        self.line_positions = {
            "ocean": 0,
            "emerald": 0,
            "crimson": 0,
        }

    @classmethod
    def rgb(cls, color, background=False, bold=True):
        r, g, b = color
        mode = 48 if background else 38
        weight = cls.BOLD if bold else ""

        return f"\033[{mode};2;{r};{g};{b}m{weight}"

    @classmethod
    def interpolate(cls, start, end, amount):
        return tuple(
            round(a + (b - a) * amount)
            for a, b in zip(start, end)
        )

    @classmethod
    def get_color(cls, colors, position):
        position = max(0.0, min(1.0, position))

        segments = len(colors) - 1
        scaled = position * segments

        index = min(int(scaled), segments - 1)
        fraction = scaled - index

        return cls.interpolate(
            colors[index],
            colors[index + 1],
            fraction
        )

    def static_solid(self, text, colors, theme="ocean"):
        if not text:
            return ""

        lines = text.splitlines(keepends=True)

        if not lines:
            return ""

        output = []

        for line in lines:
            content = line.rstrip("\r\n")
            ending = line[len(content):]

            if not content:
                output.append(ending)
                continue

            rendered = []
            length = len(content)

            for index, char in enumerate(content):
                horizontal = (
                    index / (length - 1)
                    if length > 1 else 0.5
                )

                position = horizontal * 0.78 + 0.5
                position %= 2.0

                if position > 1.0:
                    position = 2.0 - position

                color = self.get_color(colors, position)

                rendered.append(self.rgb(color) + char)

            output.append(
                "".join(rendered) + self.RESET + ending
            )

        return "".join(output)

    def gradient(self, text, colors, theme="ocean"):
        if not text:
            return ""

        lines = text.splitlines(keepends=True)

        if not lines:
            return ""

        output = []
        line_index = self.line_positions[theme]

        for line in lines:
            content = line.rstrip("\r\n")
            ending = line[len(content):]

            if not content:
                output.append(ending)
                line_index += 1
                continue

            length = len(content)
            rendered = []

            for index, char in enumerate(content):
                horizontal = (
                    index / (length - 1)
                    if length > 1 else 0.5
                )

                position = (
                    horizontal * 0.78
                    + line_index * 0.027
                )

                position %= 2.0

                if position > 1.0:
                    position = 2.0 - position

                color = self.get_color(colors, position)

                rendered.append(
                    self.rgb(color) + char
                )

            output.append(
                "".join(rendered) + self.RESET + ending
            )

            line_index += 1

        self.line_positions[theme] = line_index

        return "".join(output)

    def ocean(self, text):
        return self.static_solid(text, self.OCEAN, "ocean")

    def emerald(self, text):
        return self.static_solid(text, self.EMERALD, "emerald")

    def crimson(self, text):
        return self.static_solid(text, self.CRIMSON, "crimson")

    def rainbow(self, text):
        if not text:
            return ""

        lines = text.splitlines(keepends=True)
        output = []

        colors = self.RAINBOW
        color_count = len(colors)

        # Lower = faster transition
        transition_lines = 5

        line_index = Palette._rainbow_line_position

        for line in lines:
            content = line.rstrip("\r\n")
            ending = line[len(content):]

            if not content:
                output.append(ending)
                line_index += 1
                continue

            # Continuous position through the color sequence
            position = line_index / transition_lines

            # Find current and next colors
            current_index = int(position) % color_count
            next_index = (current_index + 1) % color_count

            # Smooth interpolation between both colors
            amount = position - int(position)

            color = self.interpolate(
                colors[current_index],
                colors[next_index],
                amount
            )

            output.append(
                self.rgb(color) + content + self.RESET + ending
            )

            line_index += 1

        # Save the exact position for every Palette instance
        Palette._rainbow_line_position = line_index

        return "".join(output)

    @property
    def error(self):
        return self.rgb(self.CRIMSON[3])

    @property
    def sky_blue(self):
        return self.rgb(self.OCEAN[4])

    @property
    def red(self):
        return self.rgb(self.CRIMSON[3])

    @property
    def magenta(self):
        return self.rgb(self.RAINBOW[10])

    @property
    def sexy_blue(self):
        return self.rgb(self.OCEAN[2])

    @property
    def grassy_green(self):
        return self.rgb(self.EMERALD[3])

    @property
    def sunny_yellow(self):
        return self.rgb(self.RAINBOW[2])

    @property
    def fucked_up_blue(self):
        return self.rgb(self.OCEAN[3])

    @property
    def better_grassy_green(self):
        return self.rgb(self.EMERALD[3])

    @property
    def mustard(self):
        return self.rgb(self.RAINBOW[2])

    @property
    def grey(self):
        return self.rgb((120, 130, 150))

    @property
    def better_purpule(self):
        return self.rgb(self.OCEAN[0])

    @property
    def fuck(self):
        return self.RESET

    def print_all(self):
        print(self.ocean("DEEP OCEAN NEON"))
        print(self.emerald("EMERALD NEON"))
        print(self.crimson("CRIMSON NEON"))

        print(self.rainbow(
            "RAINBOW GRADIENT\n"
            "RAINBOW GRADIENT\n"
            "RAINBOW GRADIENT\n"
            "RAINBOW GRADIENT\n"
            "RAINBOW GRADIENT\n"
            "RAINBOW GRADIENT\n"
            "RAINBOW GRADIENT\n"
            "RAINBOW GRADIENT\n"
            "RAINBOW GRADIENT\n"
            "RAINBOW GRADIENT\n"
            "RAINBOW GRADIENT\n"
            "RAINBOW GRADIENT"
        ))


my_palette = Palette()
