import shutil

from colorama import init
from pystyle import Colorate, Colors, Center, Col, Add, Anime

from Plugins.logger import Logger
from Plugins.colors import Palette

init(autoreset=False)

palette = Palette()


class Funcs:

    @staticmethod
    def get_input(text: str, checker=lambda x: True):

        colored_text = palette.ocean(text)

        value = input(
            colored_text + palette.rgb(Palette.WHITE)
        )

        while not checker(value):
            Logger.Error.error("Try Again")

            value = input(
                palette.ocean(text) + palette.rgb(Palette.WHITE)
            )

        return value

    @staticmethod
    def print_logo():

        logo = r"""
███╗░░░███╗░█████╗░░██████╗░██████╗░██╗░░██╗
████╗░████║██╔══██╗██╔════╝░██╔══██╗██║░░██║
██╔████╔██║███████║██║░░██╗░██████╔╝███████║
██║╚██╔╝██║██╔══██║██║░░╚██╗██╔══██╗██╔══██║
██║░╚═╝░██║██║░░██║╚██████╔╝██║░░██║██║░░██║
╚═╝░░░░░╚═╝╚═╝░░╚═╝░╚═════╝░╚═╝░░╚═╝╚═╝░░╚═╝
"""

        terminal_width = shutil.get_terminal_size().columns

        centered_logo = "\n".join(
            " " * max(0, (terminal_width - len(line)) // 2) + line
            for line in logo.splitlines()
        )

        print()
        print(palette.ocean(centered_logo))
        print()
        print()
