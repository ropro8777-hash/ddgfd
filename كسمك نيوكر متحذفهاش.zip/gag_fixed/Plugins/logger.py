from datetime import datetime

from Plugins.colors import Palette

palette = Palette()


class Logger:

    @staticmethod
    def timestamp():
        value = datetime.now().strftime("%H:%M:%S")
        return f"\033[97m[\033[0m{palette.rainbow(value)}\033[97m]\033[0m"

    @staticmethod
    def output(theme, message, name="", id=""):
        gradient = getattr(palette, theme)

        if id:
            content = (
                f"{gradient(f'{message} {name} ')}"
                f"\033[97m[\033[0m"
                f"{gradient(str(id))}"
                f"\033[97m]\033[0m"
            )
        else:
            content = gradient(f"{message} {name}".strip())

        print(
            Logger.timestamp(),
            content
        )

    class Success:

        @staticmethod
        def create(name, id=""):
            Logger.output("emerald", "Created", name, id)

        @staticmethod
        def delete(name, id=""):
            Logger.output("emerald", "Deleted", name, id)

        @staticmethod
        def change(value):
            Logger.output("emerald", value)

        @staticmethod
        def success(value):
            Logger.output("emerald", value)

    class Error:

        @staticmethod
        def create(name, reason=""):
            msg = f"Failed to Create {name}" + (f" because {reason}" if reason else "")
            Logger.output("crimson", msg)

        @staticmethod
        def delete(name, reason=""):
            msg = f"Failed to Delete {name}" + (f" because {reason}" if reason else "")
            Logger.output("crimson", msg)

        @staticmethod
        def ban(name, reason=""):
            msg = f"Failed to Ban {name}" + (f" because {reason}" if reason else "")
            Logger.output("crimson", msg)

        @staticmethod
        def change(value):
            Logger.output("crimson", f"Failed to Change {value}")

        @staticmethod
        def error(value):
            Logger.output("crimson", value)

    class Log:

        @staticmethod
        def started():
            pass
