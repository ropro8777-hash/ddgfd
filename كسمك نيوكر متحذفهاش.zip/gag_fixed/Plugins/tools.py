# language: Python, file: tools.py, target: Windows 11, Python 3.10+
import requests as req
import os
import random
import threading
from Plugins.logger import Logger

# ── Proxy pool: loaded + validated once at startup ─────────────────────────────
_proxy_pool: list = []
_proxy_lock = threading.Lock()
_proxies_loaded = False

# ── Permission cache: guild perms fetched once per session ──────────────────────
_perm_cache: dict = {}          # { permission_name: bool }
_perm_cache_ready = False
_perm_lock = threading.Lock()


def _load_and_validate_proxies(proxy_path: str = "proxies.txt") -> list:
    raw: list[dict] = []
    if not os.path.exists(proxy_path):
        return raw
    try:
        with open(proxy_path, "r", encoding="utf-8") as f:
            lines = [l.strip() for l in f if l.strip() and not l.startswith("#")]
    except Exception:
        return raw

    for line in lines:
        p = line
        for sep in [";", ",", "|"]:
            if sep in p and "://" not in p:
                parts = p.split(sep)
                if len(parts) == 4:
                    p = f"{parts[0]}:{parts[1]}:{parts[2]}:{parts[3]}"
                elif len(parts) == 2:
                    p = f"{parts[0]}:{parts[1]}"

        if "://" in p:
            proto, rest = p.split("://", 1)
        else:
            proto, rest = "http", p

        if "@" in rest:
            formatted = f"{proto}://{rest}"
        else:
            parts = rest.split(":")
            if rest.startswith("["):
                end_b = rest.find("]")
                if end_b != -1:
                    ip = rest[:end_b + 1]
                    rem_parts = rest[end_b + 1:].lstrip(":").split(":")
                    if len(rem_parts) >= 3:
                        formatted = f"{proto}://{rem_parts[1]}:{':'.join(rem_parts[2:])}@{ip}:{rem_parts[0]}"
                    elif len(rem_parts) == 1:
                        formatted = f"{proto}://{ip}:{rem_parts[0]}"
                    else:
                        formatted = f"{proto}://{ip}"
                else:
                    formatted = f"{proto}://{rest}"
            elif len(parts) >= 4:
                host, port, user, pwd = parts[0], parts[1], parts[2], ":".join(parts[3:])
                formatted = f"{proto}://{user}:{pwd}@{host}:{port}"
            else:
                formatted = f"{proto}://{rest}"

        raw.append({"http": formatted, "https": formatted})

    # Concurrent validation — test each proxy against Discord API
    valid: list[dict] = []
    test_url = "https://discord.com/api/v10/"
    results_lock = threading.Lock()

    def test_proxy(proxy_dict):
        try:
            r = req.get(test_url, proxies=proxy_dict, timeout=6)
            if r.status_code in (200, 401, 405):
                with results_lock:
                    valid.append(proxy_dict)
        except Exception:
            pass

    threads = [threading.Thread(target=test_proxy, args=(p,), daemon=True) for p in raw]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=8)

    return valid


def init_proxies(proxy_path: str = "proxies.txt"):
    """Populate the in-memory proxy pool at startup — silent, no print."""
    global _proxy_pool, _proxies_loaded
    with _proxy_lock:
        if _proxies_loaded:
            return
        valid = _load_and_validate_proxies(proxy_path)
        _proxy_pool = valid
        _proxies_loaded = True


def prime_permission_cache(guild_id: str, token: str):
    """
    Fetch guild roles + bot member roles ONCE at session start.
    Stores resolved booleans in _perm_cache so has_permission() is instant.
    """
    global _perm_cache, _perm_cache_ready
    with _perm_lock:
        if _perm_cache_ready:
            return

        perms_map = {
            "ADMINISTRATOR":               0x8,
            "MANAGE_CHANNELS":             0x10,
            "MANAGE_ROLES":                0x10000000,
            "MANAGE_GUILD":                0x20,
            "BAN_MEMBERS":                 0x4,
            "KICK_MEMBERS":                0x2,
            "MANAGE_WEBHOOKS":             0x20000000,
            "MANAGE_EMOJIS_AND_STICKERS":  0x40000000,
            "SEND_MESSAGES":               0x800,
        }

        try:
            h = {"Authorization": f"Bot {token}", "Content-Type": "application/json"}

            guild_res = req.get(Tools.api(f"guilds/{guild_id}"), headers=h, timeout=8)
            if guild_res.status_code != 200:
                # Can't reach guild — assume all perms OK so we don't block
                for k in perms_map:
                    _perm_cache[k] = True
                _perm_cache_ready = True
                return

            guild_data  = guild_res.json()
            all_roles   = {r["id"]: int(r.get("permissions", 0)) for r in guild_data.get("roles", [])}

            bot_res = req.get(Tools.api("users/@me"), headers=h, timeout=8)
            bot_id  = bot_res.json().get("id") if bot_res.status_code == 200 else None

            member_role_ids: list[str] = []
            if bot_id:
                mem_res = req.get(Tools.api(f"guilds/{guild_id}/members/{bot_id}"), headers=h, timeout=8)
                if mem_res.status_code == 200:
                    member_role_ids = mem_res.json().get("roles", [])

            # Combine @everyone perms + bot's assigned roles
            effective = all_roles.get(str(guild_id), 0)
            for rid in member_role_ids:
                effective |= all_roles.get(rid, 0)

            is_admin = bool(effective & 0x8)

            for name, bit in perms_map.items():
                _perm_cache[name] = is_admin or bool(effective & bit)

        except Exception:
            for k in perms_map:
                _perm_cache[k] = True

        _perm_cache_ready = True


def reset_permission_cache():
    global _perm_cache, _perm_cache_ready
    with _perm_lock:
        _perm_cache = {}
        _perm_cache_ready = False


class Tools:
    @staticmethod
    def get_proxy():
        with _proxy_lock:
            if not _proxy_pool:
                return None
            return random.choice(_proxy_pool)

    @staticmethod
    def request(method, url, **kwargs):
        proxy = Tools.get_proxy()
        if proxy:
            kwargs["proxies"] = proxy
        if "timeout" not in kwargs:
            kwargs["timeout"] = 10

        method_lower = method.lower()
        try:
            if method_lower == "get":
                return req.get(url, **kwargs)
            elif method_lower == "post":
                return req.post(url, **kwargs)
            elif method_lower == "delete":
                return req.delete(url, **kwargs)
            elif method_lower == "put":
                return req.put(url, **kwargs)
            elif method_lower == "patch":
                return req.patch(url, **kwargs)
            return req.request(method, url, **kwargs)
        except req.exceptions.ProxyError:
            kwargs.pop("proxies", None)
            if method_lower == "get":
                return req.get(url, **kwargs)
            elif method_lower == "post":
                return req.post(url, **kwargs)
            elif method_lower == "delete":
                return req.delete(url, **kwargs)
            elif method_lower == "put":
                return req.put(url, **kwargs)
            elif method_lower == "patch":
                return req.patch(url, **kwargs)
            return req.request(method, url, **kwargs)

    @staticmethod
    def check_token(token: str):
        try:
            r = Tools.request("get", "https://discord.com/api/v10/users/@me",
                              headers={"Authorization": f"Bot {token}"})
            return r.status_code == 200
        except Exception:
            return False

    @staticmethod
    def get_guilds(token: str):
        headers = {"Authorization": "Bot %s" % token, "Content-Type": "application/json"}
        url = Tools.api("users/@me/guilds")
        r = Tools.request("get", url, headers=headers)
        if r.status_code != 200 or not r.json():
            return False
        return [[i["id"], i["name"]] for i in r.json()]

    @staticmethod
    def api(endpoint: str):
        base = "https://discord.com/api/v10/"
        if endpoint.startswith("/"):
            endpoint = endpoint[1:]
        return base + endpoint

    @staticmethod
    def get_detailed_error(response):
        try:
            data = response.json()
            if "retry_after" in data:
                return f"Rate Limited (Retry after {data.get('retry_after')}s)"
            if "message" in data:
                return data.get("message")
        except Exception:
            pass
        codes = {
            400: "Bad Request",
            401: "Unauthorized (invalid token)",
            403: "Forbidden (missing permission)",
            404: "Not Found",
            429: "Rate Limited",
            500: "Discord Internal Error",
            503: "Discord Unavailable",
        }
        return codes.get(response.status_code, f"HTTP {response.status_code}")

    @staticmethod
    def has_permission(guild_id: str, headers: dict, permission_name: str) -> bool:
        """Instant lookup from pre-built cache. Falls back to True if cache not ready."""
        with _perm_lock:
            if _perm_cache_ready:
                return _perm_cache.get(permission_name, True)
        return True

    @staticmethod
    def check_bot_permissions(guild_id: str, headers: dict):
        try:
            res = Tools.request("get", Tools.api(f"guilds/{guild_id}"), headers=headers)
            if res.status_code == 403:
                return {"success": False, "reason": "Bot lacks access (403)"}
            elif res.status_code == 401:
                return {"success": False, "reason": "Unauthorized token (401)"}
            elif res.status_code != 200:
                return {"success": False, "reason": f"HTTP {res.status_code}"}
            return {"success": True, "reason": "OK"}
        except Exception as e:
            return {"success": False, "reason": str(e)}

    @staticmethod
    async def break_limit(base_api: str, token: str):
        """Fetch ALL guild members as raw dicts (preserves premium_since etc.)."""
        chunk_size = 1000
        members: list[dict] = []
        last_id = None

        while True:
            h = {"Authorization": f"Bot {token}"}
            parm = f"?limit={chunk_size}"
            if last_id:
                parm += f"&after={last_id}"
            r = Tools.request("get", base_api + parm, headers=h)
            if r.status_code != 200:
                break
            data = r.json()
            if not data:
                break
            members.extend(data)
            try:
                last_id = data[-1]["user"]["id"]
            except (KeyError, TypeError):
                break
            if len(data) < chunk_size:
                break

        return members

    @staticmethod
    def chunker(text, chunk_size: int) -> list:
        num, chunks = 0, []
        while num < len(text):
            chunks.append(text[num:num + chunk_size])
            num += chunk_size
        return chunks

    @staticmethod
    def information(guild_id: str, token: str):
        h = {"Authorization": f"Bot {token}"}
        u = Tools.request("get", Tools.api("users/@me"), headers=h)
        g = Tools.request("get", Tools.api(f"guilds/{guild_id}"), headers=h)
        return {
            "user":  u.json() if u.status_code == 200 else {},
            "guild": g.json() if g.status_code == 200 else {}
        }
